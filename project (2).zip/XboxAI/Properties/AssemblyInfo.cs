using System.Reflection;

[assembly: AssemblyTitle("XboxAI")]
[assembly: AssemblyProduct("XboxAI")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
