using System.Runtime.InteropServices;
using System.Text;

namespace XboxAI
{
    static class Native
    {
        const string Dll = "llama_wrap.dll";

        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int lw_load(byte[] path, int nCtx, int nThreads);

        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int lw_start(byte[] prompt, int maxNew, float temp);

        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int lw_next(byte[] buf, int len);

        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern void lw_free();

        public static byte[] Utf8Z(string s)
        {
            byte[] b = Encoding.UTF8.GetBytes(s);
            byte[] r = new byte[b.Length + 1];
            System.Array.Copy(b, r, b.Length);
            return r;
        }
    }
}
