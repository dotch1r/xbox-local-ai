using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace XboxAI
{
    public sealed partial class MainPage : Page
    {
        class Turn
        {
            public string Role;
            public string Text;
        }

        readonly List<Turn> history = new List<Turn>();
        bool ready = false;
        bool busy = false;
        bool chosen = false;
        bool turkish = false;
        int loadCode = 0;

        const int NCtx = 1024;
        const int MaxNew = 200;
        const int MaxPromptChars = 1700;

        static string MemInfo()
        {
            try
            {
                ulong lim = MemoryManager.AppMemoryUsageLimit;
                ulong use = MemoryManager.AppMemoryUsage;
                return "RAM limit: " + (lim / 1048576) + " MB, kullanım/used: " + (use / 1048576) + " MB";
            }
            catch (Exception) { return "RAM: ?"; }
        }

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Mouse imleci icin
            try
            {
                if (Window.Current.CoreWindow.PointerCursor == null)
                    Window.Current.CoreWindow.PointerCursor = new CoreCursor(CoreCursorType.Arrow, 0);
            }
            catch (Exception) { }

            EnButton.Focus(FocusState.Programmatic);
            LangStatus.Text = "Loading model... / Model yükleniyor...\n" + MemInfo();

            string modelPath = Package.Current.InstalledLocation.Path + "\\Assets\\model.gguf";
            loadCode = await Task.Run(() =>
            {
                try
                {
                    return Native.lw_load(Native.Utf8Z(modelPath), NCtx, 4);
                }
                catch (Exception ex)
                {
                    return -100 - Math.Abs(ex.HResult % 100);
                }
            });

            ready = (loadCode == 0);
            if (chosen) ApplyReadyState();
            else
                LangStatus.Text = (ready
                    ? "Model ready / Model hazır"
                    : "Model error (" + loadCode + ") / Model hatası (" + loadCode + ")") + "\n" + MemInfo();
        }

        void EnButton_Click(object sender, RoutedEventArgs e) { ChooseLanguage(false); }
        void TrButton_Click(object sender, RoutedEventArgs e) { ChooseLanguage(true); }

        void ChooseLanguage(bool tr)
        {
            if (chosen) return;
            chosen = true;
            turkish = tr;

            TitleText.Text = tr ? "Xbox AI - yerel sohbet (Qwen3 0.6B)" : "Xbox AI - local chat (Qwen3 0.6B)";
            SendButton.Content = tr ? "Gönder" : "Send";
            ClearButton.Content = tr ? "Temizle" : "Clear";
            InputBox.PlaceholderText = tr ? "Mesajını yaz, Enter ile gönder" : "Type your message, press Enter to send";

            LangPanel.Visibility = Visibility.Collapsed;
            ChatPanel.Visibility = Visibility.Visible;

            if (loadCode == 0 && ready) ApplyReadyState();
            else if (loadCode != 0 && !ready && modelFinished())
                ApplyReadyState();
            else
                StatusText.Text = tr ? "Model yükleniyor..." : "Loading model...";
        }

        bool modelFinished() { return loadCode != 0; }

        void ApplyReadyState()
        {
            if (ready)
            {
                StatusText.Text = (turkish ? "Hazır. Bir şey yaz ve Enter'a bas. " : "Ready. Type something and press Enter. ") + MemInfo();
                InputBox.IsEnabled = true;
                SendButton.IsEnabled = true;
                InputBox.Focus(FocusState.Programmatic);
            }
            else
            {
                StatusText.Text = (turkish ? "Model yüklenemedi (kod " : "Model failed to load (code ") + loadCode +
                    (turkish ? "). -1: dosya açılamadı, -2: bellek, <= -100: dll yüklenemedi."
                             : "). -1: file not opened, -2: memory, <= -100: dll not loaded.");
            }
        }

        string SystemPrompt()
        {
            return turkish
                ? "Sen yardımsever bir asistansin. Her zaman Türkçe, kısa ve net cevap ver."
                : "You are a helpful assistant. Always answer in English, briefly and clearly.";
        }

        string BuildPrompt()
        {
            while (true)
            {
                var sb = new StringBuilder();
                sb.Append("<|im_start|>system\n").Append(SystemPrompt()).Append("<|im_end|>\n");
                foreach (var t in history)
                    sb.Append("<|im_start|>").Append(t.Role).Append("\n").Append(t.Text).Append("<|im_end|>\n");
                // Qwen3: bos dusunme modunu kapat (bos <think> blogu)
                sb.Append("<|im_start|>assistant\n<think>\n\n</think>\n\n");
                string p = sb.ToString();
                if (p.Length <= MaxPromptChars || history.Count <= 1) return p;
                history.RemoveAt(0);
            }
        }

        async void Send()
        {
            if (!ready || busy) return;
            string msg = InputBox.Text.Trim();
            if (msg.Length == 0) return;

            busy = true;
            InputBox.Text = "";
            InputBox.IsEnabled = false;
            SendButton.IsEnabled = false;
            StatusText.Text = turkish ? "Düşünüyor..." : "Thinking...";

            history.Add(new Turn { Role = "user", Text = msg });
            OutputText.Text += (turkish ? "Sen: " : "You: ") + msg + "\n\nAI: ";
            string prompt = BuildPrompt();

            string reply = await Task.Run(() => Generate(prompt));

            history.Add(new Turn { Role = "assistant", Text = reply });
            OutputText.Text += "\n\n";
            ScrollDown();

            busy = false;
            InputBox.IsEnabled = true;
            SendButton.IsEnabled = true;
            StatusText.Text = turkish ? "Hazır." : "Ready.";
            InputBox.Focus(FocusState.Programmatic);
        }

        string Generate(string prompt)
        {
            var all = new StringBuilder();
            try
            {
                int n = Native.lw_start(Native.Utf8Z(prompt), MaxNew, 0.7f);
                if (n < 0)
                {
                    PostText(n == -3
                        ? (turkish ? "[Konuşma çok uzadı, Temizle'ye bas]" : "[Conversation too long, press Clear]")
                        : "[Start error " + n + "]");
                    return "";
                }
                var decoder = Encoding.UTF8.GetDecoder();
                byte[] buf = new byte[256];
                char[] chars = new char[512];
                while (true)
                {
                    int got = Native.lw_next(buf, buf.Length);
                    if (got == -1) break;
                    if (got < 0) { PostText("[Error " + got + "]"); break; }
                    if (got == 0) continue;
                    int c = decoder.GetChars(buf, 0, got, chars, 0);
                    if (c > 0)
                    {
                        string piece = new string(chars, 0, c);
                        all.Append(piece);
                        PostText(piece);
                    }
                }
            }
            catch (Exception ex)
            {
                PostText("[Error: " + ex.Message + "]");
            }
            return all.ToString();
        }

        void PostText(string s)
        {
            var _ = Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                OutputText.Text += s;
                ScrollDown();
            });
        }

        void ScrollDown()
        {
            Scroller.UpdateLayout();
            Scroller.ChangeView(null, Scroller.ScrollableHeight, null);
        }

        void InputBox_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key == VirtualKey.Enter)
            {
                e.Handled = true;
                Send();
            }
        }

        void SendButton_Click(object sender, RoutedEventArgs e) { Send(); }

        void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (busy) return;
            history.Clear();
            OutputText.Text = "";
        }
    }
}
