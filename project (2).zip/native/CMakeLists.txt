cmake_minimum_required(VERSION 3.20)
cmake_policy(SET CMP0091 NEW)
project(llama_wrap C CXX)

# Statik CRT: pakete ekstra vcruntime dll'i gerekmesin
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
# Xbox One (Jaguar): AVX ve F16C var, AVX2/FMA yok
set(GGML_AVX ON CACHE BOOL "" FORCE)
set(GGML_AVX2 OFF CACHE BOOL "" FORCE)
set(GGML_FMA OFF CACHE BOOL "" FORCE)
set(GGML_F16C ON CACHE BOOL "" FORCE)
set(GGML_AVX512 OFF CACHE BOOL "" FORCE)

add_subdirectory(${LLAMA_DIR} llama EXCLUDE_FROM_ALL)

add_library(llama_wrap SHARED wrap.cpp)
target_link_libraries(llama_wrap PRIVATE llama)
