#include "llama.h"
#include <cstring>
#include <vector>

#define EXPORT extern "C" __declspec(dllexport)

static llama_model*        g_model = nullptr;
static llama_context*      g_ctx   = nullptr;
static llama_sampler*      g_smpl  = nullptr;
static const llama_vocab*  g_vocab = nullptr;
static std::vector<llama_token> g_prompt;
static llama_token g_next = 0;
static bool g_first = true;
static int  g_nctx = 0, g_generated = 0, g_max = 0;

EXPORT int lw_load(const char* path, int n_ctx, int n_threads) {
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = false;   // UWP'de mmap sorun cikarabilir
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path, mp);
    if (!g_model) return -1;
    g_vocab = llama_model_get_vocab(g_model);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_batch = 256;
    cp.n_ubatch = 256;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) return -2;
    g_nctx = n_ctx;
    return 0;
}

EXPORT int lw_start(const char* prompt, int max_new, float temp) {
    if (!g_ctx) return -1;
    llama_memory_clear(llama_get_memory(g_ctx), true);

    if (g_smpl) { llama_sampler_free(g_smpl); g_smpl = nullptr; }
    g_smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(g_smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(g_smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(g_smpl, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(g_smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    int len = (int)strlen(prompt);
    int n = -llama_tokenize(g_vocab, prompt, len, nullptr, 0, true, true);
    if (n <= 0) return -2;
    if (n >= g_nctx - 16) return -3;   // prompt cok uzun
    g_prompt.resize(n);
    if (llama_tokenize(g_vocab, prompt, len, g_prompt.data(), n, true, true) < 0) return -2;

    g_generated = 0;
    g_max = max_new;
    g_first = true;
    return n;
}

// >=0: yazilan bayt sayisi, -1: bitti, -2: hata
EXPORT int lw_next(char* buf, int buflen) {
    if (!g_ctx) return -2;
    if (g_generated >= g_max) return -1;

    if (g_first) {
        g_first = false;
        int total = (int)g_prompt.size();
        for (int i = 0; i < total; i += 256) {
            int cnt = total - i < 256 ? total - i : 256;
            llama_batch b = llama_batch_get_one(g_prompt.data() + i, cnt);
            if (llama_decode(g_ctx, b) != 0) return -2;
        }
    } else {
        llama_batch b = llama_batch_get_one(&g_next, 1);
        if (llama_decode(g_ctx, b) != 0) return -2;
    }

    g_next = llama_sampler_sample(g_smpl, g_ctx, -1);
    if (llama_vocab_is_eog(g_vocab, g_next)) return -1;
    g_generated++;
    int n = llama_token_to_piece(g_vocab, g_next, buf, buflen, 0, true);
    return n < 0 ? 0 : n;
}

EXPORT void lw_free() {
    if (g_smpl)  { llama_sampler_free(g_smpl); g_smpl = nullptr; }
    if (g_ctx)   { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
