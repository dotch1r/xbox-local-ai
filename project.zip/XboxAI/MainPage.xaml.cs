using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace XboxAI
{
    public sealed partial class MainPage : Page
    {
        class Turn
        {
            public string Role;
            public string Text;
        }

        readonly List<Turn> history = new List<Turn>();
        bool ready = false;
        bool busy = false;

        const int NCtx = 2048;
        const int MaxNew = 400;
        const int MaxPromptChars = 3500;

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            string modelPath = Package.Current.InstalledLocation.Path + "\\Assets\\model.gguf";
            int rc = await Task.Run(() =>
            {
                try
                {
                    return Native.lw_load(Native.Utf8Z(modelPath), NCtx, 4);
                }
                catch (Exception ex)
                {
                    return -100 - Math.Abs(ex.HResult % 100);
                }
            });

            if (rc == 0)
            {
                ready = true;
                StatusText.Text = "Hazir. Bir sey yaz ve Enter'a bas.";
                InputBox.IsEnabled = true;
                SendButton.IsEnabled = true;
                InputBox.Focus(FocusState.Programmatic);
            }
            else
            {
                StatusText.Text = "Model yuklenemedi (kod " + rc + "). -1: model dosyasi acilamadi, -2: bellek/baglam hatasi, <= -100: dll yuklenemedi.";
            }
        }

        string BuildPrompt()
        {
            while (true)
            {
                var sb = new StringBuilder();
                sb.Append("<|im_start|>system\nSen yardimsever bir asistansin. Kullanicinin dilinde kisa ve net cevap ver.<|im_end|>\n");
                foreach (var t in history)
                    sb.Append("<|im_start|>").Append(t.Role).Append("\n").Append(t.Text).Append("<|im_end|>\n");
                sb.Append("<|im_start|>assistant\n");
                string p = sb.ToString();
                if (p.Length <= MaxPromptChars || history.Count <= 1) return p;
                history.RemoveAt(0);
            }
        }

        async void Send()
        {
            if (!ready || busy) return;
            string msg = InputBox.Text.Trim();
            if (msg.Length == 0) return;

            busy = true;
            InputBox.Text = "";
            InputBox.IsEnabled = false;
            SendButton.IsEnabled = false;
            StatusText.Text = "Dusunuyor...";

            history.Add(new Turn { Role = "user", Text = msg });
            OutputText.Text += "Sen: " + msg + "\n\nAI: ";
            string prompt = BuildPrompt();

            string reply = await Task.Run(() => Generate(prompt));

            history.Add(new Turn { Role = "assistant", Text = reply });
            OutputText.Text += "\n\n";
            ScrollDown();

            busy = false;
            InputBox.IsEnabled = true;
            SendButton.IsEnabled = true;
            StatusText.Text = "Hazir.";
            InputBox.Focus(FocusState.Programmatic);
        }

        string Generate(string prompt)
        {
            var all = new StringBuilder();
            try
            {
                int n = Native.lw_start(Native.Utf8Z(prompt), MaxNew, 0.7f);
                if (n < 0)
                {
                    PostText(n == -3 ? "[Konusma cok uzadi, Temizle'ye bas]" : "[Baslatma hatasi " + n + "]");
                    return "";
                }
                var decoder = Encoding.UTF8.GetDecoder();
                byte[] buf = new byte[256];
                char[] chars = new char[512];
                while (true)
                {
                    int got = Native.lw_next(buf, buf.Length);
                    if (got == -1) break;
                    if (got < 0) { PostText("[Uretim hatasi " + got + "]"); break; }
                    if (got == 0) continue;
                    int c = decoder.GetChars(buf, 0, got, chars, 0);
                    if (c > 0)
                    {
                        string piece = new string(chars, 0, c);
                        all.Append(piece);
                        PostText(piece);
                    }
                }
            }
            catch (Exception ex)
            {
                PostText("[Hata: " + ex.Message + "]");
            }
            return all.ToString();
        }

        void PostText(string s)
        {
            var _ = Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                OutputText.Text += s;
                ScrollDown();
            });
        }

        void ScrollDown()
        {
            Scroller.UpdateLayout();
            Scroller.ChangeView(null, Scroller.ScrollableHeight, null);
        }

        void InputBox_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key == VirtualKey.Enter)
            {
                e.Handled = true;
                Send();
            }
        }

        void SendButton_Click(object sender, RoutedEventArgs e)
        {
            Send();
        }

        void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (busy) return;
            history.Clear();
            OutputText.Text = "";
        }
    }
}
